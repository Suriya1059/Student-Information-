import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DemomoduleRoutingModule } from './demomodule-routing.module';


@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    DemomoduleRoutingModule
  ]
})
export class DemomoduleModule { }
