export interface Employee {
    id?: number;
    name: string;
    branch: string;
    category: string;
    image?: File;
  }
  